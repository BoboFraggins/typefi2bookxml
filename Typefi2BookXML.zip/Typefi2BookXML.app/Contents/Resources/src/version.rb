module Typefi2bookxml
  VERSION = '0.5.1'
end
