module Typefi2bookxml
  VERSION = '0.5.0'
end
