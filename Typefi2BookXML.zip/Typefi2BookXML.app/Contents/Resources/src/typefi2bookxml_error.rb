class Typefi2bookxmlError < StandardError
end
