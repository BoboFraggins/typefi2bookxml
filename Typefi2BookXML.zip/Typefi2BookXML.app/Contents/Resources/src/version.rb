module Typefi2bookxml
  VERSION = '0.0.2'
end
