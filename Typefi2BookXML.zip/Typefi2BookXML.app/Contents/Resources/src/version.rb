module Typefi2bookxml
  VERSION = '0.0.1'
end
