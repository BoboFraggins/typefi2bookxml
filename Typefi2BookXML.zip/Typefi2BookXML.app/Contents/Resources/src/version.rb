module Typefi2bookxml
  VERSION = '0.9.3'
end
