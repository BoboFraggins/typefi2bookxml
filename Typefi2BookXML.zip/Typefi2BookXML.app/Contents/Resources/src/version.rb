module Typefi2bookxml
  VERSION = '0.0.3'
end
